#ifndef CRON_H_INCLUDED
#define CRON_H_INCLUDED

void refresh_schedule();
size_t cron_tick();

#endif // CRON_H_INCLUDED
